ESTE ARCHIVO CONTIENE:

SPMP[Alimnova]LineaBaseV3.0.docx
SPMP[Alimnova]Descripci�nCasosDeUso_V(5.0)xlsx
SPMP[Alimnova]DiagCasosDeUsoSerTMonopoly.jpg
SPMP[Alimnova]DiagCasosDeUsoSisTMonopoly.jpg
SPMP[Alimnova]EspecificacionCasosUsoV0.5.2.docx
SPMP[Alimnova]GanttHito1.pdf
SPMP[Alimnova]GanttHito2.pdf
SPMP[Alimnova]GanttHito3.png
SPMP[Alimnova]PerttHito1.pdf
SPMP[Alimnova]PerttHito2.pdf
SPMP[Alimnova]PerttHito3.png
SPMP[Alimnova]PuntosFuncionalesv1.0.xlsx
SPMP[Alimnova]ReglasMonopolio.pdf
SRS[Alimnova]DescripcionRequerimientosNoFuncionalesV1.0.xlsx
SRS[Alimnova]DescripcionRequerimientosFuncionalesV1.0.xlsx
SRS[Alimnova]EncuestasAnalisisRequerimientosV1.0.xlxs
SRS[Alimnova]EspecificacionRequerimientosV2.5.1.docx
SRS[Alimnova]LineaBaseV3.0.0.docx
SRS[Alimnova]ListaChequeoRequerimientosv0.9xlsx
SRS[Alimnova]PresentacionV1.0.pptx
SRS[Alimnova]TrazabilidadRequerimientosV0.5xlsx
SRS[Alimnova]DOCUMENTACION_REQ_V2.6.1LineaBase.docx
SRS[Alimnova]DescripcionRequerimientosV.xlxs






